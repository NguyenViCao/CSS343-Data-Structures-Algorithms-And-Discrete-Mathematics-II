CSS 343
Professor: Dong Si
Spring 2022
Coder: Nguyen Vi Cao

note on assignment 1:
- g++ ubuntu version: g++ (Ubuntu 9.3.0-17ubuntu1~20.04) 9.3.0
- IDE: Visual Studio 2019
- output is similar to the provided lab1.output from canvas